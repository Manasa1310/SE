# Patient - Physiotheropist Appointment App

This project includes a full-stack web application that allows patients and Physiotheropists to schedule and manage appointments. 



## Technologies

- **Frontend:**
  - Created using React. 
  - Utilizes libraries such as React Router, Tailwind, Formik, Yup, and Toastify.

- **Backend:**
  - Developed with Node.js and Express.js.
  - Utilizes MongoDB as the database, integrated with Mongoose.
  
- **Authentication and Authorization:** 
  - User authentication is managed using Token Authentication.
  - Authorization is implemented using React Router's security features.

## Project Structure

- **client:** Frontend code
  - **src:**
    - **components:** React components
    - **pages:** Application pages
    - **utils:** Helper functions and constants

- **server:** Backend code
  - **controllers:** MongoDB operations and business logic
  - **models:** MongoDB schemas
  - **routes:** API routes
  - **config:** Firebase and other configuration files

## Installation

1. **Frontend Installation:**
   ```bash
   cd client
   npm install
   npm start
