'use strict'

module.exports = {
    userTypes : ["Admin", "Physiotheropist", "Patient"],
    genders : ["Male", "Female", "Others"],
    insurance : ["Private", "Compulsory"],
    dayNames: ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"]
}