"use strict"

const router = require('express').Router()
/* ------------------------------------------------------- */
// routes/Physiotheropist:

//const permissions = require('../middlewares/permissions')
const Physiotheropist = require('../controllers/Physiotheropist')

const upload = require('../middlewares/upload')

// URL: /Physiotheropists

router.route('/')
    .get(Physiotheropist.list)
    .post(upload.single('avatar'), Physiotheropist.create)

router.route('/:id')
    .get(Physiotheropist.read)
    .put(upload.single('avatar'), Physiotheropist.update)
    .patch(upload.single('avatar'), Physiotheropist.update)
    .delete(Physiotheropist.delete)

/* ------------------------------------------------------- */
module.exports = router