"use strict"

// Physiotheropist Controller:

const Physiotheropist = require('../models/Physiotheropist')

module.exports = {

    list: async (req, res) => {
        /*
            #swagger.tags = ["Physiotheropists"]
            #swagger.summary = "List Physiotheropists"
            #swagger.description = `
                You can send query with endpoint for search[], sort[], page and limit.
                <ul> Examples:
                    <li>URL/?<b>search[field1]=value1&search[field2]=value2</b></li>
                    <li>URL/?<b>sort[field1]=1&sort[field2]=-1</b></li>
                    <li>URL/?<b>page=2&limit=1</b></li>
                </ul>
            `
        */

        const data = await res.getModelList(Physiotheropist, {}, ["branchId", "cityId", "complaints"])

        // res.status(200).send({
        //     error: false,
        //     details: await res.getModelListDetails(Physiotheropist),
        //     data
        // })
        
        // FOR REACT PROJECT:
        res.status(200).json({
            number:data.length,
            data
        })
    },

    create: async (req, res) => {
        /*
            #swagger.tags = ["Physiotheropists"]
            #swagger.summary = "Create Physiotheropist"
            #swagger.parameters['body'] = {
                in: 'body',
                required: true,
                schema: { $ref: '#/definitions/Physiotheropist' }
            }
        */

        const data = await Physiotheropist.create(req.body)

        res.status(201).send({
            error: false,
            data
        })
    },

    read: async (req, res) => {
        /*
            #swagger.tags = ["Physiotheropists"]
            #swagger.summary = "Get Single Physiotheropist"
        */

        const data = await Physiotheropist.findOne({ _id: req.params.id }).populate(["branchId", "cityId", "complaints"])

        res.status(200).send({
            error: false,
            data
        })
    },

    update: async (req, res) => {
        /*
            #swagger.tags = ["Physiotheropists"]
            #swagger.summary = "Update Physiotheropist"
            #swagger.parameters['body'] = {
                in: 'body',
                required: true,
                schema: { $ref: '#/definitions/Physiotheropist' }
            }
        */

        const data = await Physiotheropist.updateOne({ _id: req.params.id }, req.body, { runValidators: true })

        res.status(202).send({
            error: false,
            data,
            new: await Physiotheropist.findOne({ _id: req.params.id })
        })
    },

    delete: async (req, res) => {
        /*
            #swagger.tags = ["Physiotheropists"]
            #swagger.summary = "Delete Physiotheropist"
        */

        const data = await Physiotheropist.deleteOne({ _id: req.params.id })

        res.status(data.deletedCount ? 204 : 404).send({
            error: !data.deletedCount,
            data
        })
    },
}