import React from "react";

const api = () => {
  return <div></div>;
};

export default api;
