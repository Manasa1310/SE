import React from "react";

const notification = () => {
  return <div></div>;
};

export default notification;
