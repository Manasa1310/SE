import React from "react";

const appointment = () => {
  return <div></div>;
};

export default appointment;
