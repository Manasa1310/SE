import React from "react";

const messaging = () => {
  return <div></div>;
};

export default messaging;
