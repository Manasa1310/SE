import React from "react";

const clinic = () => {
  return <div></div>;
};

export default clinic;
