import React from "react";

const auth = () => {
  return <div></div>;
};

export default auth;
