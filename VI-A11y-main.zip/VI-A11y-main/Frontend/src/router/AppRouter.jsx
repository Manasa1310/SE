import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Home from "../pages/home/Home";
import RegisterPhysiotheropist from "../pages/auth/RegisterPhysiotheropist";
import RegisterPatient from "../pages/auth/RegisterPatient";
import DetailPhysiotheropist from "../pages/detailPhysiotheropist/DetailPhysiotheropist";
import SearchPhysiotheropist from "../pages/searchPhysiotheropist/SearchPhysiotheropist";
import Login from "../pages/auth/Login";
import PrivateRouter from "./PrivateRouter";
import AdminPanel from "../pages/panels/adminPanel/AdminPanel";
import PhysiotheropistPanel from "../pages/panels/PhysiotheropistPanel/PhysiotheropistPanel";
import PatientPanel from "../pages/panels/patientPanel/PatientPanel";
import About from "../pages/about/About";

const AppRouter = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home/>} />
        <Route path="/search" element={<SearchPhysiotheropist/>} />
        <Route path="/search/:id" element={<DetailPhysiotheropist/>} />
        <Route path="/login" element={<Login />} />
        <Route path="/regPhysiotheropist" element={<RegisterPhysiotheropist />} />
        <Route path="/regpatient" element={<RegisterPatient />} />
        <Route path="/about" element={<About/>} />
        <Route element={<PrivateRouter />}>
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/Physiotheropist" element={<PhysiotheropistPanel />} />
          <Route path="/patient" element={<PatientPanel />} />
        </Route>
      </Routes>
    </Router>
  )

};

export default AppRouter;