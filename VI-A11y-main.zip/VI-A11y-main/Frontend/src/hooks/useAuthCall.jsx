import axios from "axios";
import { fetchFail, fetchStart, loginSuccess, logoutSuccess, registerSuccess } from "../features/authSlice";
import { useNavigate } from "react-router-dom"
import { useDispatch } from "react-redux"


const url = process.env.REACT_APP_BASE_URL

const useAuthCall = () => {
    const navigate = useNavigate()
    const dispatch = useDispatch()

    /* -------------------------------------------------------------------------- */
    /*                               The Login Process                            */
    /* -------------------------------------------------------------------------- */

    const login = async (userData) => {  
        dispatch(fetchStart())
        try {
            const { data } = await axios.post(`${url}/auth/login`,userData)
            dispatch(loginSuccess(data))
            navigate("/")
        } catch (error) {
            console.log(error.message);
            dispatch(fetchFail())
        }
    }
    /* -------------------------------------------------------------------------- */
    /*                              The Logout Process                            */
    /* -------------------------------------------------------------------------- */


    const logout = async () => {  
        dispatch(fetchStart())
        try {
            await axios.post(`${url}/auth/logout`)
            dispatch(logoutSuccess())
        } catch (error) {
            dispatch(fetchFail())
            console.log(error);
        }
    }

    /* -------------------------------------------------------------------------- */
    /*                            The Patient Registration                        */
    /* -------------------------------------------------------------------------- */

    const regPatient = async (userData) => { 
        dispatch(fetchStart())
        try {
            const { data } = await axios.post(`${url}/auth/register`, userData)
            dispatch(registerSuccess(data))
            console.log(data)
            navigate("/patient")
        } catch (error) {
            dispatch(fetchFail())
            console.log(error);
        }
    }

    /* -------------------------------------------------------------------------- */
    /*                            The Physiotheropist Registration                         */
    /* -------------------------------------------------------------------------- */

    const regPhysiotheropist = async (userData) => { 
        dispatch(fetchStart())
        try {
            const { data } = await axios.post(`${url}/auth/register`, userData)
            dispatch(registerSuccess(data))
            console.log(data)
            navigate("/Physiotheropist")
        } catch (error) {
            dispatch(fetchFail())
            console.log(error);
        }
    }

    return {
        login, logout, regPatient, regPhysiotheropist
    }

}
export default useAuthCall