import React from 'react'
import "./cardPhysiotheropist.css"
import PhysiotheropistImage from './assets/Physiotheropist.png'
import starIcon from './assets/star.png'
import { useNavigate, useParams } from 'react-router-dom';



const CardPhysiotheropist = ({id, street, title, firstName, lastName, zipCode, branchId, cityId}) => {
  const navigate = useNavigate()

  return (
    <div className='cardPhysiotheropist'>
      <div className="PhysiotheropistImage">
        <img src={PhysiotheropistImage} alt="PhysiotheropistImage" />
      </div>
      <div className="PhysiotheropistInfo">

        <div className="Physiotheropist-middleInfo">
          <div className="PhysiotheropistName">
            <h2><span>{title}.</span>  {firstName} {lastName}</h2>
            <h3>{branchId?.name}</h3>
            <p className='address'><span>Adresse: </span>{street.split(" ").slice(0, 2).join(" ")} </p>
            <p className='city'>{zipCode}, {cityId?.name} </p>
          </div>

          <div className="PhysiotheropistRate">
            <div className="starRate">
              <img src={starIcon} alt="" />
              <p>4.9</p>
            </div>
            <p> <span>5</span> Jahre Erfahrung</p>

          </div>
        </div>

        <button className="Physiotheropist-info-btn" onClick={()=>navigate(`/search/${id}/`)}>MEHR INFOS</button>
      </div>


    </div>
  )
}

export default CardPhysiotheropist