import React from "react";

const SpecialNotifications = () => {
  return <div></div>;
};

export default SpecialNotifications;
