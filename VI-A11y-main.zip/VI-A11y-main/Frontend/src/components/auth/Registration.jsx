import React from "react";

const Registration = () => {
  return <div></div>;
};

export default Registration;
