import React from "react";

const PatientHistory = () => {
  return <div></div>;
};

export default PatientHistory;
