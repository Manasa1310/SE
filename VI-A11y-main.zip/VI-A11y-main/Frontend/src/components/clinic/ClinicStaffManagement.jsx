import React from "react";

const ClinicStaffManagement = () => {
  return <div></div>;
};

export default ClinicStaffManagement;
