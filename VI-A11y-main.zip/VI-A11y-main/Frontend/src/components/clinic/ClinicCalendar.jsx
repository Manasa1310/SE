import React from "react";

const ClinicCalendar = () => {
  return <div></div>;
};

export default ClinicCalendar;
