import React from "react";

const PhysiotheropistPatientMessaging = () => {
  return <div></div>;
};

export default PhysiotheropistPatientMessaging;
