import React from "react";

const PatientPhysiotheropistMessaging = () => {
  return <div></div>;
};

export default PatientPhysiotheropistMessaging;
