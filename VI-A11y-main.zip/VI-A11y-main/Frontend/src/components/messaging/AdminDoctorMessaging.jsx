import React from "react";

const AdminPhysiotheropistMessaging = () => {
  return <div></div>;
};

export default AdminPhysiotheropistMessaging;
