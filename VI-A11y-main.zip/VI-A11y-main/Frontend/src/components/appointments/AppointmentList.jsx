import React from "react";

const AppointmentList = () => {
  return <div></div>;
};

export default AppointmentList;
