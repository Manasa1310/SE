import React from "react";

const AppointmentCalendar = () => {
  return <div></div>;
};

export default AppointmentCalendar;
