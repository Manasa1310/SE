import React from "react";

const AppointmentModal = () => {
  return <div></div>;
};

export default AppointmentModal;
