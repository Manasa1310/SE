import React from 'react'

import locationIcon from '../../assets/locationIcon.png'
import phoneIcon from '../../assets/phone.png'
import webIcon from '../../assets/web.png'
import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'



const PhysiotheropistProfil = ({ branchId, cityId, phone, website, title, firstName, lastName, avatar }) => {

  const { currentUser } = useSelector((state) => state.auth)
  const navigate = useNavigate()
  const check = () => {
    currentUser ? navigate("/patient") : navigate("/login")
  }

  return (
    <>
    <div className='flex flex-col justify-center items-center p-1 profil-Physiotheropist'>
      <img className='Physiotheropist-image' src={avatar ? avatar : 'https://www.thewmch.com/wp-content/uploads/2023/02/female-Physiotheropist-using-her-digital-tablet-free-vector.jpg'} alt="Physiotheropist-pic"/>
      <h1 className='text-xl font-bold Physiotheropist-profil-name'> {title}. {firstName} {lastName}</h1>
      <h2 className='text-xl Physiotheropist-profil-name'>{branchId?.name}</h2>
      </div>  
      <div className='flex justify-start Physiotheropist-profil-location'>
        <img src={locationIcon} className="me-2 w-4 h-6" alt="locationIcon" />
        <h3>{cityId?.name}</h3>
      </div>
      <div className='flex Physiotheropist-profil-phone'>
        <img src={phoneIcon} className="me-1 w-5 h-5" alt="phoneIcon" />
        <h3>{phone}</h3>
      </div>
      <div className='flex Physiotheropist-profil-website'>
      <img src={webIcon} className="me-1 w-6 h-6" alt="webIcon" />
      {website ? <a href="www.example.com"> {website}</a> : "Keine Webseite Vorhanden"}
      </div>
      <button className='flex justify-center termin-button duration-150 mx-auto' onClick={() => check()}>TERMIN VEREINBAREN</button>
      
    
    </>
    
  )
}

export default PhysiotheropistProfil