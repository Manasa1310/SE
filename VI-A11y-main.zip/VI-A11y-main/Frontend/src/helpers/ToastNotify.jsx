import React from "react";

const ToastNotify = () => {
  return <div></div>;
};

export default ToastNotify;
