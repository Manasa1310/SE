import React from "react";

const clinicSlice = () => {
  return <div></div>;
};

export default clinicSlice;
