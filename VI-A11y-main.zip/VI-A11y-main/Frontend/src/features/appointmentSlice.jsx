import React from "react";

const appointmentSlice = () => {
  return <div></div>;
};

export default appointmentSlice;
