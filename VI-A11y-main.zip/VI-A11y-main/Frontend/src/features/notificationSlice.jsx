import React from "react";

const notificationSlice = () => {
  return <div></div>;
};

export default notificationSlice;
