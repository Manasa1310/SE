import React from "react";

const messagingSlice = () => {
  return <div></div>;
};

export default messagingSlice;
