import React, { useEffect } from 'react'
import Sidebar from '../../components/Physiotheropist/Sidebar'
import Symptom from '../../components/Physiotheropist/Symptom'
import PhysiotheropistProfil from '../../components/Physiotheropist/ProfilPhysiotheropist'
import AppointmentCalendar from '../../components/Physiotheropist/AppointmentCalendar'
import AboutPhysiotheropist from '../../components/Physiotheropist/AboutPhysiotheropist'
import { useParams } from 'react-router-dom';
import "../../components/Physiotheropist/PhysiotheropistPages.css"
import useDataCall from '../../hooks/useDataCall'
import { useSelector } from 'react-redux'
import Loading from '../loading/Loading'

const DetailPhysiotheropist = () => {
  const {id} = useParams();
  const {getData} = useDataCall()
  const {Physiotheropists} = useSelector((state)=>state.data)

  const thisPhysiotheropist = Physiotheropists?.data?.filter((item, i) => {return item.id === id})

  useEffect(() => {
    
    getData("Physiotheropists")
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])



  return (
    <>
    {
      !thisPhysiotheropist?.length ? <Loading/> : (
        <div className="grid grid-rows-5 grid-cols-8 w-100">
          <div className="row-span-5 col-span-1"><Sidebar/></div>
          <div className="row-span-1 col-span-7"><Symptom {...thisPhysiotheropist[0]}/></div>
          <div className="row-span-4 col-span-2"><PhysiotheropistProfil {...thisPhysiotheropist[0]}/></div>
          <div className="row-span-4 col-span-3"><AppointmentCalendar {...thisPhysiotheropist[0]}/></div>
          <div className="row-span-4 col-span-2"><AboutPhysiotheropist {...thisPhysiotheropist[0]}/></div>
    
    </div>
      )
    }
    </>
  )
  
}

export default DetailPhysiotheropist