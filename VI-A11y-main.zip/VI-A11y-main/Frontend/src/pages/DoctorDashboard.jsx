import React from "react";

const PhysiotheropistDashboard = () => {
  return <div></div>;
};

export default PhysiotheropistDashboard;
