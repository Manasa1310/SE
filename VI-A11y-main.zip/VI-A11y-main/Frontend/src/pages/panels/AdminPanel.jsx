import React from "react";

const AdminPanel = () => {
  return <div></div>;
};

export default AdminPanel;
