import React from "react";

const PhysiotheropistPanel = () => {
  return <div></div>;
};

export default PhysiotheropistPanel;
