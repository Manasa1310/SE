import React from 'react'

const PatientPanel = () => {
  return (
    <div>PatientPanel</div>
  )
}

export default PatientPanel