import React, { useEffect, useState } from "react";
import Sidebar from "../../../components/dashboard/PhysiotheropistDashboard/sidebar/Sidebar";
import ProcessBar from "../../../components/dashboard/PhysiotheropistDashboard/profil/processBar/ProcessBar";
import Main from "../../../components/dashboard/PhysiotheropistDashboard/profil/main/Main";

import successImg from "../../../assets/success.png"
import "./PhysiotheropistPanel.css";
import { useSelector } from "react-redux";
import useDataCall from "../../../hooks/useDataCall";
import Loading from "../../loading/Loading";

const PhysiotheropistPanel = () => {
  const { getData } = useDataCall()
  const { Physiotheropists } = useSelector((state) => state.data)
  const { currentUser } = useSelector((state) => state.auth)


  useEffect(() => {
    getData("Physiotheropists")
  }, [])

  const PhysiotheropistProfile = Physiotheropists?.data?.filter((item) => (currentUser === item.email))


  return (

    <>
      {PhysiotheropistProfile && PhysiotheropistProfile.length > 0 ?

        <div className="dashboard">
          <div className="dpanel-sidebar">
            <Sidebar />
          </div>
          <div className="dpanel-main">
            <div className="main-content">
              <Main/>
            </div>
          </div>
        </div> : <Loading />}
    </>
  );
};

export default PhysiotheropistPanel;
