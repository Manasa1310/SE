import React from "react";

const PatientDashboard = () => {
  return <div></div>;
};

export default PatientDashboard;
