import React, { useEffect, useState, useRef } from 'react';
import "./searchPhysiotheropist.css";
import CardPhysiotheropist from '../../components/cardPhysiotheropist/CardPhysiotheropist';
import useDataCall from '../../hooks/useDataCall';
import { useSelector } from 'react-redux';
import Loading from '../loading/Loading';
import Footer from '../../components/footer/Footer';
import searchIcon from "../../assets/ic_baseline-search.png";
import locationIcon from "../../assets/locationIcon.png";
import Header from '../../components/header/Header';
import { useLocation } from 'react-router-dom';

const SearchPhysiotheropist = () => {
  const { getData } = useDataCall();
  const { Physiotheropists, loading } = useSelector((state) => state.data);

  const [filteredPhysiotheropists, setfilteredPhysiotheropists] = useState([])

  const searchParamsRef = useRef({
    name: "",
    branch: "",
    city: "",
    zipCodes: "",
  });
//  const {state} = useLocation()
//  console.log(state);

  // const filteredPhysiotheropistsRef = useRef([]);

  useEffect(() => {
    getData("Physiotheropists");
  }, []);

  console.log("Physiotheropists", Physiotheropists);

  const handleInputChange = (field, value) => {
    searchParamsRef.current = {
      ...searchParamsRef.current,
      [field]: value,
    };
  };
  console.log("Render:");

  const handleSearch = (event) => {
    event.preventDefault();
  
    console.log("searchParamsRef:", searchParamsRef.current);
    
    if (Physiotheropists && Physiotheropists.data) {
      const filteredResults = Physiotheropists.data.filter((Physiotheropist) => {
        // Önce Physiotheropist nesnesinin tanımlı olduğunu kontrol edin
        if (!Physiotheropist) return false;
  
        // Şimdi diğer özellikleri kontrol edin
        const firstNameMatch = Physiotheropist.firstName.toLowerCase().includes(searchParamsRef.current.name?.toLowerCase() || "");
        const lastNameMatch = Physiotheropist.lastName.toLowerCase().includes(searchParamsRef.current.name?.toLowerCase() || "");
        const branchMatch = Physiotheropist.branchId && Physiotheropist.branchId.name.toLowerCase().includes(searchParamsRef.current.name?.toLowerCase() || "");
        const cityMatch = Physiotheropist.cityId && Physiotheropist.cityId.name.toLowerCase().includes(searchParamsRef.current.city?.toLowerCase() || "");
        const zipCodeMatch = Physiotheropist.zipCode == searchParamsRef.current?.city;
  
        return (firstNameMatch || lastNameMatch || branchMatch) && (cityMatch || zipCodeMatch);
      });
  
      console.log("filteredResults:", filteredResults)
  
      setfilteredPhysiotheropists(filteredResults);
      
    }
  }

  return (
    <div className="main-container">
      <div className="nav">
        <Header />
      </div>
      <form onSubmit={handleSearch}>
        <div className="input">
          <div className="input-left-box">
            <img src={searchIcon} alt="searchIcon" className='searchIcon' />
            <input
              type="text"
              className="input-left"
              placeholder='Name oder Fachgebiet'
              // ref={searchParamsRef}
              onChange={(e) => handleInputChange('name', e.target.value)}
            />
          </div>
          <div className="input-middleLine"></div>
          <div className="input-right-box">
            <img src={locationIcon} alt="locationIcon" className='locationIcon' />
            <input
              type="text"
              className="input-right"
              placeholder='z.B. Berlin oder 12345'
              // ref={searchParamsRef}
              onChange={(e) => handleInputChange('city', e.target.value)}
            />
          </div>
          <div className="input-right-box">
            <button type="submit" className="input-btn" >Suchen</button>
          </div>
        </div>
      </form>
      <div className="input-fixed"></div>
      <div className="main-cardPhysiotheropist" >
        {loading ? (
          <Loading />
        ) : filteredPhysiotheropists?.length ? (
          filteredPhysiotheropists?.map((item, i) => <CardPhysiotheropist key={i} {...item} />)
        ) : (
          <p className='h-full pt-[200px] text-sky-900'>No matching Physiotheropists found.</p>
        )}
      </div>
      <div className="search-Physiotheropist-footer">
        <Footer />
      </div>
    </div>
  );
};

export default SearchPhysiotheropist;


